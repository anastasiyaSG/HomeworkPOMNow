﻿using HomeworkPOM.Factories;
using HomeworkPOM.Pages;
using HomeworkPOM.Models;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace HomeworkPOM.Tests.GoogleSearch01
{
    class GoogleSearch
    {
        [TestFixture]
        public class GooglePage : BaseTest
        {
            private GooglePage _googlePage;
            private GoogleModels _user;
            

            public GooglePage(IWebDriver driver)
            {
                Driver = driver;
            }

            [SetUp]
            public void Setup()
            {
                Initialize();
                Driver.Navigate().GoToUrl("https://www.google.com/");
                _googlePage = new GooglePage(Driver);
                _user = GoogleFromFactory.Create();
            }

            [Test]
            public void CheckFirstResultName()
            { 
            //Arange
                _user.SearchPanel = string.Empty;

                //Act
                _googlePage.FillGoogle(_user);

                //Assert
                _googlePage.AssertHeadlineResult(_googlePage.FirstResult);
              
            }

     
 
           [TearDown]
            public void TearDown()
            {
                Driver.Quit();
            }
        }
    }


}


