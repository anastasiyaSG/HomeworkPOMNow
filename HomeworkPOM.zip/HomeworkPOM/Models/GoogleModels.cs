﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HomeworkPOM.Models
{
   public class GoogleModels
    { 
        public string SearchPanel { get; set; }
      
    }
}

