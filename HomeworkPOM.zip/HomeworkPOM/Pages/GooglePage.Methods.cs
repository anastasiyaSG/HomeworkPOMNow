﻿using HomeworkPOM.Models;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace HomeworkPOM.Pages
{
    public partial class GooglePage :BasePage
    {
        public GooglePage(IWebDriver driver)
             : base(driver)
        { }
        public void FillGoogle(GoogleModels user)
        {
            SearchPanel.SendKeys(user.SearchPanel+Keys.Enter);
            
            
        }

    }
}
