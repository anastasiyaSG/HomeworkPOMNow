﻿
using System;
using System.Collections.Generic;
using System.Text;
using HomeworkPOM;
using OpenQA.Selenium;

namespace HomeworkPOM.Pages
{
   public partial class GooglePage : BasePage

    {
       public IWebElement SearchPanel => Driver.FindElement(By.Name("q"));

        public IWebElement FirstResult => Driver.FindElement(By.CssSelector("#rso > div:nth-child(1) > div > div.r > a > div"));

        public IWebElement SeleniumHeadlineResult => Driver.FindElement(By.CssSelector("#rso > div:nth-child(1) > div > div.r > a > h3"));


    }
}

