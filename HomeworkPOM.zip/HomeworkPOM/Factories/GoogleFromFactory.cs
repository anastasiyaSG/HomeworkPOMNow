﻿using HomeworkPOM.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace HomeworkPOM.Factories
{
    public static class GoogleFromFactory
    {
        public static GoogleModels Create()
        {
            return new GoogleModels
            {
                SearchPanel = "selenium",
          
            };
        }
    }
}

